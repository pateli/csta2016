import random

class Individual():
    '''
    ' Evolves an individual from its parent identity.
    ' Specify either parent or identity;
    ' if both are provided, identity is ignored.
    '''
    
    FIDELITY = {'sameF':0.1 , 'deleteF':0.3 , 'insertF':0.3 , 'mutateF':0.3}         # Probabilities
    LITTER_SIZES = [0,1,2,2,2,2,3,4]             # Litter size is chosen randomly from this list
    LUCA = 'random high school is great!' # Last universal common ancestor
    NUM_GENERATIONS = 4                        # Number of generations to simulate

    def __init__(self,identity=None,parent=None):
        if parent==None:
            self.identity=identity           # If there is no parent provided, set the identity as given
        else:
            self.identity=parent.mutate()    # Create the new identity based on mutation
            parent.children.append(self)     # Add new Individual to parent's list of children
        self.parent=parent                   # Set the new Indidivual's parent
        self.children=[]                     # Set the new Indidivual's children to an empty list

            
    def __len__(self):
        return len(self.identity)           # make the len() function work on Individuals
        
    def __str__(self):
        return '\''+self.identity+'\''     # make the print function work, enclosed by single quotes
        
    #the most important method of Individual:
    def mutate(self):
        '''
        ' Return a (potentially) mutated identity, copied from the Indidivual.
        ' Parameters specify relative frequency with which offspring have the
        ' same string, a deleted character, an inserted character, or a mutated character.
        '''
        
        # Four helper functions:
        def randLetter():
            return chr(random.randint(65,65+25)) # pick a random capital letter A through Z

        def insert(a,b,pos):
            ''' 
            ' Puts string b inside string a, with pos characters of string a before b.
            ' 0<=pos<len(a)
            '''
            return a[0:pos]+b+a[pos:]     
            
        def delete(a,pos):
            '''
            ' Deletes one char from string a, with pos characters first.
            ' 0<=pos<len(a)
            '''
            return a[0:pos]+a[pos+1:]
            
        def replace(a,b,pos):
            '''
            ' Replace one character in a with single character b, preceded by pos characters of a
            ' 0<=pos<len(a)-1
            '''
            return a[0:pos]+b+a[pos+1:]
                
        # pick: noChange, deletion, insertion, pointMutation    
        option=random.random()                            
        
        #no change
        if option < Individual.FIDELITY['sameF']:       
            return self.identity
        
        #delete
        elif option < Individual.FIDELITY['sameF'] + Individual.FIDELITY['deleteF']: 
            deleteLocation = random.randint( 0,len(self))
            return delete(self.identity , deleteLocation)
        
        #insert
        elif option < Individual.FIDELITY['sameF'] + Individual.FIDELITY['deleteF'] + Individual.FIDELITY['insertF']: 
            
            insertLocation=random.randint(0,len(self))
            return insert(self.identity,randLetter(),insertLocation)   
       
       #point mutate
        else:      
            changeLocation=random.randint(0,len(self)-1)
            return replace(self.identity,randLetter(),changeLocation) 
       
    # method of Individual that makes a set of n children:
    def reproduce(self,n):
        '''
        ' Returns a list of n progeny
        '''
        progeny=[]                              # start with an empty list of progeny
        for i in range(n):
            progeny+=[Individual(parent=self)]  # add a new Indidivual to the list of progeny
        return progeny
    
def generation(genPrev):         
    '''
    ' accepts a list of Individuals for parents
    ' returns a list of Indidivuals for progeny
    '''
    progeny=[]
    Individual.LITTER_SIZES=[1,1,1,3,3,3,6] ################# ADJUSTING THIS CHANGES RESULTS
    for indiv in genPrev:
        progeny+=indiv.reproduce(random.choice(Individual.LITTER_SIZES))  
    return progeny
    
def simulate(numGenerations=Individual.NUM_GENERATIONS, luca=Individual.LUCA):
    '''
    ' reproduces a string for several generations
    ' luca = a string of the last universal common ancsetor
    '''
     
    gen=range(numGenerations)
    gen[0]=[Individual(identity=luca)] 
    
    # create a list of all subsequent generations 
    # where each element generation is a list of individuals
    for i in range(1,numGenerations):
        gen[i]=generation(gen[i-1])
        
    # print a numbered list of indidivuals in the last generation    
    print "--------------------------------"
    print
    print "Current generation:"
    print
    for i in range(len(gen[numGenerations-1])):
        print i,gen[numGenerations-1][i] 

    # print a phylogenetic tree
    print "--------------------------------"
    print
    print "Phylogeny:"
    print
    
    # define a recursive function to print a tree
    def treePrint(indiv,indent):
        print indent,indiv #this is all that needs to happen in the base case
        if indiv.children==[]:
            return
        else:
            for child in indiv.children:
                #call the function from within the function
                treePrint(child,indent+'   ')  # the recursive call prints a subtree further indented  
    
    #call the recursive function
    treePrint(gen[0][0],'')
    
    